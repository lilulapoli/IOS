import UIKit

var greeting = "Hello, playground"

//№ 1 Написать функцию, которая определяет, четное число или нет
var numberArray = [23, 24, 12, 9, 88, 99, 13]
for numbers in numberArray{
    if numbers % 2 == 0 {
        print("\(numbers) четное число")
    } else {
        print("\(numbers) нечетное число")
    }
}
// № 2 Написать функцию, которая определяет, делится ли число без остатка на 3.
for number in numberArray {

    if number % 3 == 0 {
        print("\(number) делится на 3 без остатка")
    } else {
        print("\(number) делится на 3 с остатком")
    }
}
// № 3 Создать возрастающий массив из 100 чисел.
var index : Array<Int> = []
for a in 1...100{
    index.append(a)
}
    print(index)

// № 4 Удалить из этого массива все четные числа и все числа, которые не делятся на 3.
var remove = index.filter {$0 % 2 != 0 && $0 % 3 == 0}
print(remove)

// № 5 

